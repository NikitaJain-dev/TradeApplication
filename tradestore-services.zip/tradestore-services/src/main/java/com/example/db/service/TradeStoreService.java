package com.example.db.service;

import java.time.LocalDate;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.db.model.TradeStore;
import com.example.db.repository.TradeStoreRepository;

@Service
@Transactional
public class TradeStoreService {
	
	private static final Logger log = LoggerFactory.getLogger(TradeStoreService.class);

	@Autowired
	TradeStoreRepository repository;
	
	public void storeTrade(TradeStore tradeStore) throws Exception {
		if (validateTrade(tradeStore)) {
			tradeStore.setCreatedDate(LocalDate.now());
			repository.save(tradeStore);
		} else {
			throw new Exception(tradeStore.getTradeId() + "  Trade Id is not found");
		}

	}
	
	private boolean validateTrade(TradeStore trade) {
		boolean validMaturityDate = trade.getMaturityDate().isBefore(LocalDate.now()) ? false : true;
		if (validMaturityDate) {
			Optional<TradeStore> existingTrade = repository.findById(trade.getTradeId());
			if (existingTrade.isPresent()) {
				return (trade.getVersion() >=  existingTrade.get().getVersion()) ?true:false;
			} else {
				return true;
			}
		}
		return false;
	}
	
    public void updateExpiryFlagOfTrade(){

		repository.findAll().stream().forEach(t -> {
			if (!(t.getMaturityDate().isBefore(LocalDate.now()))) {
				t.setExpiredFlag("Y");
				log.info("Trade which needs to updated {}", t);
				repository.save(t);
			}
		});
    }
   
}
