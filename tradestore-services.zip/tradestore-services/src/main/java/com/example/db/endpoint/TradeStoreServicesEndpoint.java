package com.example.db.endpoint;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.db.model.TradeStore;
import com.example.db.repository.TradeStoreRepository;
import com.example.db.service.TradeStoreService;

@RestController
public class TradeStoreServicesEndpoint {

	@Autowired
	TradeStoreService tradeStoreService;
	
	@Autowired
	TradeStoreRepository repository;
	
	@GetMapping("/trade")
	public List<TradeStore> getAllTrades(){
		return repository.findAll();
	}
	
	 @PostMapping("/trade")
	 public ResponseEntity<String> storeTrades(@RequestBody TradeStore trade) throws Exception{
		 
		 tradeStoreService.storeTrade(trade);
	     return ResponseEntity.status(HttpStatus.OK).build();
	 }
}
