package com.example.db;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.db.endpoint.TradeStoreServicesEndpoint;
import com.example.db.model.TradeStore;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TradestoreServicesApplication.class)
public class TradestoreServicesApplicationTests {

	@Autowired
	private TradeStoreServicesEndpoint tradeStoreServicesEndpoint;
	
	@Test
	public void testTradeValidateAndStore_successful() throws Exception {
		ResponseEntity responseEntity = tradeStoreServicesEndpoint.storeTrades(createTrade("T1",1,LocalDate.now()));
		assertEquals(ResponseEntity.status(HttpStatus.OK).build(),responseEntity);
		List<TradeStore> tradeList =tradeStoreServicesEndpoint.getAllTrades();
		assertEquals(1, tradeList.size());
		assertEquals("T1",tradeList.get(0).getTradeId());
	}
	
	private TradeStore createTrade(String tradeId,int version,LocalDate  maturityDate){
		TradeStore trade = new TradeStore();
		trade.setTradeId(tradeId);
		trade.setBookId(tradeId+"B1");
		trade.setVersion(version);
		trade.setCounterParty(tradeId+"Cpty");
		trade.setMaturityDate(maturityDate);
		trade.setExpiredFlag("Y");
		return trade;
	}

}
